<?php
include "../admin/include/init.php";
include "../admin/layout/header.php";
include "../admin/include/check_session.php";
?>
<main>
    <section class="admin-section">
        <div class="container">
            <div class="with-box-shadow ">
                <div class="section-title text-center">
                    <h5>Dashboard</h5>
                </div>

            </div>
        </div>
    </section>
</main>
<?php
include "../admin/layout/footer.php";
?>
