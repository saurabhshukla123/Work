<script type="text/javascript" src="<?php echo $assets_url; ?>js/main.js"></script>
<script>
    CKEDITOR.replace( 'editor1' );
</script>
</body>
</html>
<!-- Footer End -->