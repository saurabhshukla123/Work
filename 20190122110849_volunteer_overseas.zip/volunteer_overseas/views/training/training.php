<?php
    $assets_url = ASSETS_URL;
    $indexPageData = json_decode($indexPageData);
?>
<main id="home">

    <div class="banner-wrap banner-style2">
            <div class="banner-img page-banner hidden-xs inner-banner" style="background: url(<?php echo $assets_url; ?>images/banners/contact-banner.jpg);">
            </div>
            <div class="banner-img page-banner visible-xs inner-banner" style="background:url(<?php echo $assets_url; ?>images/contact-banner-mobile.jpg);"></div>
            <div class="banner-text align-center">
                <div class="container">
                    <h2>Training MVC</h2>
                </div>
            </div>
     </div>
     <div> Training started </div>
</main>
</div>
	<!----content end------>
