document.write(
		'<script type="text/javascript" src="'+assets_url+'js/jquery.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/fastclick.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/bootstrap.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/modernizr.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/respond.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/dropkick.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/owl.carousel.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/owl.carousel2.thumbs.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/imagesloaded.pkgd.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/jquery-imagefill-min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/swiper.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/select2.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/jquery-ui.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/nouislider.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/jquery.waypoints.min.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/wNumb.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/jquery.sticky.js"></script>' +
		'<script type="text/javascript" src="'+assets_url+'js/general.js"></script>'
);
